
from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os

ADMIN_ID = 5000936733  # замените на свой Telegram user_id

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'

def init_db():
    with sqlite3.connect("database.db") as conn:
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance INTEGER DEFAULT 1000000
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS gifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            filename TEXT,
            price INTEGER DEFAULT 1000,
            stock INTEGER DEFAULT 999999
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            gift_id INTEGER
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS upgrades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            gift_name TEXT,
            filename TEXT
        )''')
        conn.commit()

@app.before_request
def before_request():
    init_db()

@app.route("/")
def index():
    user_id = request.args.get("user_id", type=int)
    if not user_id:
        return "No user_id"

    with sqlite3.connect("database.db") as conn:
        c = conn.cursor()
        c.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        user = c.fetchone()
        if not user:
            c.execute("INSERT INTO users (user_id) VALUES (?)", (user_id,))
            conn.commit()
            balance = 1000000
        else:
            balance = user[0]

        c.execute("""
            SELECT g.id, g.name, g.filename FROM gifts g
            JOIN purchases p ON p.gift_id = g.id
            WHERE p.user_id = ?
        """, (user_id,))
        gifts = c.fetchall()

        upgrades = {}
        for gift in gifts:
            c.execute("SELECT filename FROM upgrades WHERE gift_name = ?", (gift[1],))
            upgrades[gift[0]] = [row[0] for row in c.fetchall()]

    return render_template("profile.html", user_id=user_id, balance=balance, gifts=gifts, upgrades=upgrades)

@app.route("/shop")
def shop():
    user_id = request.args.get("user_id", type=int)
    with sqlite3.connect("database.db") as conn:
        gifts = conn.execute("SELECT * FROM gifts").fetchall()
    return render_template("shop.html", gifts=gifts, user_id=user_id)

@app.route("/buy/<int:gift_id>")
def buy_gift(gift_id):
    user_id = request.args.get("user_id", type=int)
    if not user_id:
        return "User ID missing"

    with sqlite3.connect("database.db") as conn:
        c = conn.cursor()
        c.execute("SELECT price, stock FROM gifts WHERE id = ?", (gift_id,))
        result = c.fetchone()
        if not result:
            return "Gift not found"
        price, stock = result
        if stock <= 0:
            return "❌ Подарок закончился!"

        c.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        user = c.fetchone()
        if not user:
            return "User not found"
        balance = user[0]

        if balance < price:
            return "❌ Недостаточно средств!"

        c.execute("UPDATE users SET balance = balance - ? WHERE user_id = ?", (price, user_id))
        c.execute("INSERT INTO purchases (user_id, gift_id) VALUES (?, ?)", (user_id, gift_id))
        c.execute("UPDATE gifts SET stock = stock - 1 WHERE id = ?", (gift_id,))
        conn.commit()
    return redirect(url_for("shop", user_id=user_id))

@app.route("/admin", methods=["GET"])
def admin():
    user_id = request.args.get("user_id", type=int)
    if user_id != ADMIN_ID:
        return "Access denied"
    return render_template("admin.html", user_id=user_id)

@app.route("/admin/add_gift", methods=["POST"])
def add_gift():
    name = request.form["name"]
    price = int(request.form.get("price", 1000))
    stock = int(request.form.get("stock", 999999))
    file = request.files["file"]
    if file and file.filename.endswith(".tgs"):
        path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(path)
        with sqlite3.connect("database.db") as conn:
            conn.execute("INSERT INTO gifts (name, filename, price, stock) VALUES (?, ?, ?, ?)",
                         (name, file.filename, price, stock))
        return redirect(url_for("admin", user_id=ADMIN_ID))
    return "Invalid file"

@app.route("/admin/add_upgrade", methods=["GET", "POST"])
def add_upgrade():
    user_id = request.args.get("user_id", type=int)
    if user_id != ADMIN_ID:
        return "Access denied"

    if request.method == "POST":
        name = request.form["gift_name"]
        file = request.files["file"]
        if file and file.filename.endswith(".tgs"):
            path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(path)
            with sqlite3.connect("database.db") as conn:
                conn.execute("INSERT INTO upgrades (gift_name, filename) VALUES (?, ?)", (name, file.filename))
            return redirect(url_for("admin", user_id=user_id))
        return "Invalid file"

    return render_template("add_upgrade.html", user_id=user_id)

if __name__ == "__main__":
    app.run(debug=True)
